d3 = (function(){
  var d3 = {version: "3.3.6"}; // semver
